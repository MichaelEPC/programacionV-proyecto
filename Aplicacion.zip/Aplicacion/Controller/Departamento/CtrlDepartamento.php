<?php

class CtrlDepartamento{

    public function read(){
        include_once '../View/Departamento/listDepartamento.php';
    }

}